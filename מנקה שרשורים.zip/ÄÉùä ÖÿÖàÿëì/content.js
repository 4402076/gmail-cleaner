// פונקציה שמוחקת את הציטוט מיד כשהוא מופיע
function removeGmailQuote() {
    const quotes = document.querySelectorAll('.gmail_quote');
    quotes.forEach(quote => {
        quote.remove();
    });
}

// מאזין לשינויים בדף (כמו פתיחת חלון השב)
const observer = new MutationObserver((mutations) => {
    for (let mutation of mutations) {
        if (mutation.addedNodes.length) {
            removeGmailQuote();
        }
    }
});

// הפעלת המעקב על כל גוף הדף
observer.observe(document.body, { childList: true, subtree: true });